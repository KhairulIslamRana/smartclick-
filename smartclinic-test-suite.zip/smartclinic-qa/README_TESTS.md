# SmartClinic+ – Automated Test Suite (SENG205 Assessment 3, Section 11)

Proof-of-concept core services (`smartclinic/core.py`) and automated tests TC-01 to TC-18.

## Run locally
```bash
pip install -r requirements-dev.txt
python -m pytest -v --cov=smartclinic --cov-report=term-missing --cov-fail-under=80
```
Expected: 22 passed, ~96% coverage.

## CI
`.github/workflows/tests.yml` runs the suite on every push/pull request to `main` and `develop`
and fails the build if coverage drops below 80%.

## Test ID map
| File | Test cases | Requirements |
|---|---|---|
| tests/test_appointments.py | TC-01 – TC-07 | FR-01, NFR-01, NFR-02, NFR-05 |
| tests/test_security.py | TC-08 – TC-15 | FR-04, FR-06, FR-07, NFR-01, NFR-03 |
| tests/test_queue.py | TC-16 – TC-18 | FR-02 |

All test data is synthetic. No real patient information is used.
