"""SmartClinic+ core logic: authentication, RBAC, appointment booking and smart queue.

Proof-of-concept for SENG205 Assessment 3 test evidence. Uses SQLite so the
tests run anywhere; production target is MySQL/PostgreSQL with the same
partial unique index strategy.
"""
import hashlib
import heapq
import hmac
import itertools
import os
import sqlite3
from datetime import datetime

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
    id INTEGER PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    pw_hash BLOB NOT NULL,
    salt BLOB NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('patient','doctor','nurse','admin'))
);
CREATE TABLE IF NOT EXISTS appointments(
    id INTEGER PRIMARY KEY,
    patient_id INTEGER NOT NULL REFERENCES users(id),
    doctor_id INTEGER NOT NULL REFERENCES users(id),
    slot_start TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'booked'
        CHECK (status IN ('booked','cancelled','completed'))
);
-- NFR-02: only one ACTIVE booking per doctor per slot, enforced by the database
CREATE UNIQUE INDEX IF NOT EXISTS ux_active_slot
    ON appointments(doctor_id, slot_start) WHERE status = 'booked';
CREATE TABLE IF NOT EXISTS records(
    id INTEGER PRIMARY KEY,
    patient_id INTEGER NOT NULL REFERENCES users(id),
    note TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS tasks(
    id INTEGER PRIMARY KEY,
    nurse_id INTEGER NOT NULL REFERENCES users(id),
    description TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'to_do'
        CHECK (status IN ('to_do','in_progress','done'))
);
"""


class BookingError(Exception):
    """Raised when an appointment cannot be created or changed."""


class AuthError(Exception):
    """Raised when login fails."""


class AccessDenied(Exception):
    """Raised when RBAC blocks an action."""


def connect(path=":memory:"):
    conn = sqlite3.connect(path, timeout=10, isolation_level=None, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.executescript(SCHEMA)
    return conn


# ---------- Authentication (FR login, NFR-01, NFR-03) ----------
def _hash(password, salt):
    return hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 200_000)


def create_user(conn, username, password, role):
    if len(password) < 8:
        raise ValueError("Password must be at least 8 characters")
    salt = os.urandom(16)
    cur = conn.execute(
        "INSERT INTO users(username, pw_hash, salt, role) VALUES (?,?,?,?)",
        (username, _hash(password, salt), salt, role),
    )
    return cur.lastrowid


def authenticate(conn, username, password):
    row = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
    # Same generic message for unknown user and wrong password (avoids user enumeration)
    if row is None or not hmac.compare_digest(_hash(password, row["salt"]), row["pw_hash"]):
        raise AuthError("Invalid username or password")
    return {"id": row["id"], "username": row["username"], "role": row["role"]}


# ---------- Appointments (FR-01, NFR-02) ----------
def _parse_slot(slot_start, now):
    try:
        slot = datetime.fromisoformat(slot_start)
    except (TypeError, ValueError):
        raise BookingError("Invalid date/time format")
    if slot <= now:
        raise BookingError("Cannot book a time in the past")
    return slot


def book(conn, patient_id, doctor_id, slot_start, now=None):
    _parse_slot(slot_start, now or datetime.now())
    role = conn.execute("SELECT role FROM users WHERE id = ?", (doctor_id,)).fetchone()
    if role is None or role["role"] != "doctor":
        raise BookingError("Selected clinician is not a doctor")
    try:
        conn.execute("BEGIN IMMEDIATE")
        cur = conn.execute(
            "INSERT INTO appointments(patient_id, doctor_id, slot_start) VALUES (?,?,?)",
            (patient_id, doctor_id, slot_start),
        )
        conn.execute("COMMIT")
        return cur.lastrowid
    except sqlite3.IntegrityError:
        conn.execute("ROLLBACK")
        raise BookingError("Time slot is no longer available")


def cancel(conn, appointment_id, user):
    appt = conn.execute("SELECT * FROM appointments WHERE id = ?", (appointment_id,)).fetchone()
    if appt is None:
        raise BookingError("Appointment not found")
    if user["role"] == "patient" and appt["patient_id"] != user["id"]:
        raise AccessDenied("Patients may only cancel their own appointments")
    conn.execute("UPDATE appointments SET status = 'cancelled' WHERE id = ?", (appointment_id,))


def reschedule(conn, appointment_id, user, new_slot, now=None):
    appt = conn.execute("SELECT * FROM appointments WHERE id = ?", (appointment_id,)).fetchone()
    if appt is None or appt["status"] != "booked":
        raise BookingError("Only active appointments can be rescheduled")
    new_id = book(conn, appt["patient_id"], appt["doctor_id"], new_slot, now)  # fails safely if taken
    cancel(conn, appointment_id, user)
    return new_id


def status_of(conn, appointment_id):
    return conn.execute("SELECT status FROM appointments WHERE id = ?", (appointment_id,)).fetchone()["status"]


# ---------- Electronic health records with RBAC (FR-07, NFR-01) ----------
PERMISSIONS = {
    "doctor": {"read_record", "write_record", "prescribe"},
    "nurse": {"read_record", "update_task"},
    "patient": {"read_own_record"},
    "admin": {"manage_users", "view_dashboard"},  # least privilege: no clinical notes
}


def read_record(conn, user, patient_id):
    perms = PERMISSIONS.get(user["role"], set())
    allowed = "read_record" in perms or ("read_own_record" in perms and user["id"] == patient_id)
    if not allowed:
        raise AccessDenied(f"{user['role']} is not authorised to view this record")
    return [r["note"] for r in conn.execute("SELECT note FROM records WHERE patient_id = ?", (patient_id,))]


def update_task(conn, user, task_id, new_status):
    if "update_task" not in PERMISSIONS.get(user["role"], set()):
        raise AccessDenied("Only nursing staff can update tasks")
    cur = conn.execute("UPDATE tasks SET status = ? WHERE id = ? AND nurse_id = ?", (new_status, task_id, user["id"]))
    if cur.rowcount == 0:
        raise AccessDenied("Task is not assigned to this user")


# ---------- Smart queue (FR-02) ----------
class SmartQueue:
    """Emergency patients are served first; otherwise first checked-in, first served."""

    def __init__(self):
        self._heap, self._order, self.status = [], itertools.count(), {}

    def check_in(self, patient_id, emergency=False):
        if self.status.get(patient_id) in {"Waiting", "Called"}:
            raise ValueError("Patient already in queue")
        heapq.heappush(self._heap, (0 if emergency else 1, next(self._order), patient_id))
        self.status[patient_id] = "Waiting"

    def call_next(self):
        while self._heap:
            _, _, pid = heapq.heappop(self._heap)
            if self.status.get(pid) == "Waiting":
                self.status[pid] = "Called"
                return pid
        return None

    def cancel(self, patient_id):
        self.status[patient_id] = "Cancelled"

    def waiting(self):
        return sum(1 for s in self.status.values() if s == "Waiting")
