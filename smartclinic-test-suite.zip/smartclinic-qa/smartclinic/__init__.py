"""SmartClinic+ proof-of-concept core services used for unit and integration testing."""
