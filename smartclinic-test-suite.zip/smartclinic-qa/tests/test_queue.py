import pytest
from smartclinic.core import SmartQueue


def test_TC16_check_in_adds_patient_to_queue():
    q = SmartQueue()
    q.check_in(101)
    assert q.status[101] == "Waiting" and q.waiting() == 1


def test_TC17_emergency_served_before_routine():
    q = SmartQueue()
    q.check_in(101); q.check_in(102); q.check_in(900, emergency=True)
    assert [q.call_next(), q.call_next(), q.call_next()] == [900, 101, 102]


def test_TC18_cancelled_patient_skipped_and_no_duplicates():
    q = SmartQueue()
    q.check_in(101); q.check_in(102)
    with pytest.raises(ValueError):
        q.check_in(101)
    q.cancel(101)
    assert q.call_next() == 102 and q.call_next() is None
