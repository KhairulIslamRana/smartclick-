import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
import pytest
from smartclinic import core

FUTURE = "2030-03-02T09:00"


@pytest.fixture
def clinic(tmp_path):
    """Isolated test database seeded with synthetic (non-real) users only."""
    conn = core.connect(str(tmp_path / "test.db"))
    ids = {
        "pat1": core.create_user(conn, "pat1", "Patient#2030", "patient"),
        "pat2": core.create_user(conn, "pat2", "Patient#2031", "patient"),
        "doc": core.create_user(conn, "doc", "Doctor#2030", "doctor"),
        "nurse": core.create_user(conn, "nurse", "Nurse#2030", "nurse"),
        "admin": core.create_user(conn, "admin", "Admin#2030", "admin"),
    }
    conn.execute("INSERT INTO records(patient_id, note) VALUES (?, 'Synthetic note: seasonal allergy')", (ids["pat1"],))
    conn.execute("INSERT INTO tasks(nurse_id, description) VALUES (?, 'Record vitals')", (ids["nurse"],))
    return conn, ids, tmp_path / "test.db"


def user(ids, name, role):
    return {"id": ids[name], "username": name, "role": role}
