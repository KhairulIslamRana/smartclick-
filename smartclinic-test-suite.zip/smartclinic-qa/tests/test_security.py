import pytest
from smartclinic import core
from conftest import user


def test_TC08_valid_login(clinic):
    conn, _, _ = clinic
    assert core.authenticate(conn, "doc", "Doctor#2030")["role"] == "doctor"


@pytest.mark.parametrize("username,password", [("doc", "wrong-pass"), ("ghost", "Doctor#2030")])
def test_TC09_invalid_login_generic_error(clinic, username, password):
    conn, _, _ = clinic
    with pytest.raises(core.AuthError, match="Invalid username or password"):
        core.authenticate(conn, username, password)


def test_TC10_passwords_not_stored_in_plain_text(clinic):
    conn, _, _ = clinic
    stored = conn.execute("SELECT pw_hash FROM users WHERE username='doc'").fetchone()[0]
    assert b"Doctor#2030" not in stored and len(stored) == 32


def test_TC11_doctor_can_read_record(clinic):
    conn, ids, _ = clinic
    assert core.read_record(conn, user(ids, "doc", "doctor"), ids["pat1"])


def test_TC12_patient_reads_only_own_record(clinic):
    conn, ids, _ = clinic
    assert core.read_record(conn, user(ids, "pat1", "patient"), ids["pat1"])
    with pytest.raises(core.AccessDenied):
        core.read_record(conn, user(ids, "pat2", "patient"), ids["pat1"])


def test_TC13_admin_denied_clinical_record(clinic):
    conn, ids, _ = clinic
    with pytest.raises(core.AccessDenied):
        core.read_record(conn, user(ids, "admin", "admin"), ids["pat1"])


def test_TC14_nurse_updates_own_task_only(clinic):
    conn, ids, _ = clinic
    core.update_task(conn, user(ids, "nurse", "nurse"), 1, "done")
    assert conn.execute("SELECT status FROM tasks WHERE id=1").fetchone()[0] == "done"
    with pytest.raises(core.AccessDenied):
        core.update_task(conn, user(ids, "doc", "doctor"), 1, "to_do")


def test_TC15_weak_password_rejected(clinic):
    conn, _, _ = clinic
    with pytest.raises(ValueError):
        core.create_user(conn, "weak", "123", "patient")
