import threading
import pytest
from smartclinic import core
from conftest import FUTURE, user


def test_TC01_book_available_slot(clinic):
    conn, ids, _ = clinic
    appt = core.book(conn, ids["pat1"], ids["doc"], FUTURE)
    assert core.status_of(conn, appt) == "booked"


def test_TC02_reject_already_booked_slot(clinic):
    conn, ids, _ = clinic
    core.book(conn, ids["pat1"], ids["doc"], FUTURE)
    with pytest.raises(core.BookingError, match="no longer available"):
        core.book(conn, ids["pat2"], ids["doc"], FUTURE)


def test_TC03_cancel_frees_slot(clinic):
    conn, ids, _ = clinic
    appt = core.book(conn, ids["pat1"], ids["doc"], FUTURE)
    core.cancel(conn, appt, user(ids, "pat1", "patient"))
    assert core.status_of(conn, appt) == "cancelled"
    assert core.book(conn, ids["pat2"], ids["doc"], FUTURE)  # slot reusable


def test_TC04_reschedule_to_free_slot(clinic):
    conn, ids, _ = clinic
    appt = core.book(conn, ids["pat1"], ids["doc"], FUTURE)
    new = core.reschedule(conn, appt, user(ids, "pat1", "patient"), "2030-03-02T10:00")
    assert core.status_of(conn, appt) == "cancelled" and core.status_of(conn, new) == "booked"


def test_TC04b_reschedule_to_taken_slot_keeps_original(clinic):
    conn, ids, _ = clinic
    appt = core.book(conn, ids["pat1"], ids["doc"], FUTURE)
    core.book(conn, ids["pat2"], ids["doc"], "2030-03-02T10:00")
    with pytest.raises(core.BookingError):
        core.reschedule(conn, appt, user(ids, "pat1", "patient"), "2030-03-02T10:00")
    assert core.status_of(conn, appt) == "booked"


@pytest.mark.parametrize("slot", ["2020-01-01T09:00", "not-a-date", ""])
def test_TC05_reject_past_or_invalid_time(clinic, slot):
    conn, ids, _ = clinic
    with pytest.raises(core.BookingError):
        core.book(conn, ids["pat1"], ids["doc"], slot)


def test_TC06_patient_cannot_cancel_other_patients_booking(clinic):
    conn, ids, _ = clinic
    appt = core.book(conn, ids["pat1"], ids["doc"], FUTURE)
    with pytest.raises(core.AccessDenied):
        core.cancel(conn, appt, user(ids, "pat2", "patient"))


def test_TC07_concurrent_booking_only_one_succeeds(clinic):
    """NFR-02: 20 simultaneous requests for one slot -> exactly one booking."""
    conn, ids, db_path = clinic
    results, barrier = [], threading.Barrier(20)

    def attempt(pid):
        c = core.connect(str(db_path))
        barrier.wait()
        try:
            core.book(c, pid, ids["doc"], FUTURE)
            results.append("ok")
        except core.BookingError:
            results.append("rejected")
        finally:
            c.close()

    threads = [threading.Thread(target=attempt, args=(ids["pat1"] if i % 2 else ids["pat2"],)) for i in range(20)]
    [t.start() for t in threads]
    [t.join() for t in threads]
    assert results.count("ok") == 1 and results.count("rejected") == 19
    active = conn.execute("SELECT COUNT(*) FROM appointments WHERE status='booked'").fetchone()[0]
    assert active == 1
